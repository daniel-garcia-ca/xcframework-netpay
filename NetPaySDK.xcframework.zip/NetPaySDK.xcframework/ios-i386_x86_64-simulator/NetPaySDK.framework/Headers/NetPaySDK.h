#import <UIKit/UIKit.h>

FOUNDATION_EXPORT double NetPaySDKVersionNumber;
FOUNDATION_EXPORT const unsigned char NetPaySDKVersionString[];

#import <NetPaySDK/NPConstants.h>

#include<ifaddrs.h>

@import Foundation;


typedef NSString * NPSourceTypeValue NS_EXTENSIBLE_STRING_ENUM;

typedef NSString * NPSupportedCurrencyCode NS_EXTENSIBLE_STRING_ENUM;

extern NPSupportedCurrencyCode const _Nonnull NPSupportedCurrencyCodeMXN;

